﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using QuickKartMVCCoreWebApp.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartMVCCoreWebApp.Controllers
{
    public class ProductController : Controller
    {
        // GET: /<controller>/
        static List<Product> prod = new List<Product>();
        public IActionResult Index()
        {
            return View(prod);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product p)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", p);
            }
            else
            {
                prod.Add(p);
                return RedirectToAction("Index");
            }
        }
    }
}
