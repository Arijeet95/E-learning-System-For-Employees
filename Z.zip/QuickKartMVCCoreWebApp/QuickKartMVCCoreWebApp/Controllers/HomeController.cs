﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QuickKartMVCCoreWebApp.Models;

namespace QuickKartMVCCoreWebApp.Controllers
{
    public class HomeController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}

        public string Index(string id)
        {
            if (id == null)
                return "This my 1st MVC Core application";
            else
                return "Youe passed id as :" + id;
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Login()
        {
            ViewBag.Countries = new List<string> { "India", "Japan", "France" };
            return View();
        }

        public ActionResult CheckOffer()
        {
            return View();
        }

        public RedirectResult GoToOffer()
        {
            return Redirect("/Home/CheckOffer");
        }

        public JsonResult GetProducts()
        {
            object[] data = { "Laptop", "Mobiles", "Books", "Novels" };
            return Json(data);
        }

        //[HttpPost]
        //public IActionResult CheckRole(IFormCollection frm)
        //{
        //    string userId = frm["name"];
        //    string password = frm["pwd"];
        //    string role = "admin";
        //    string checkbox = frm["RememberMe"];

        //    string username = userId.Split('@')[0];

        //    if(checkbox == "on")
        //    {
        //        //Used to create cookie
        //        CookieOptions opt = new CookieOptions();
        //        // cookie expiration time
        //        opt.Expires = DateTime.Now.AddDays(1);
        //        Response.Cookies.Append("UserId", userId, opt);
        //        Response.Cookies.Append("Password", password,opt);
        //    }


        //    if (role.Equals("admin"))
        //    {
        //        //SetString method is used to take data into session variables
        //        //HttpContext.Session.SetString("uid", userId);
        //        //HttpContext.Session.SetString("role", role);
        //        //return RedirectToAction("AdminHome", "Admin");
        //        return Redirect("/Admin/AdminHome?username=" + username);

        //    }
        //    else
        //    {
        //        return RedirectToAction("Index","Customer");
        //    }
        //}

        [HttpPost]
        public IActionResult CheckRole(IFormCollection frm)
        {
            string userId = frm["name"];
            string password = frm["pwd"];
            string role = "admin";
            string checkbox = frm["RememberMe"];
            

            if (role.Equals("admin"))
            {
                //SetString method is used to take data into session variables
                HttpContext.Session.SetString("uid", userId);
                HttpContext.Session.SetString("role", role);
                return RedirectToAction("AdminHome", "Admin");
                //return Redirect("/Admin/AdminHome?username=" + username);

            }
            else
            {
                return RedirectToAction("Index", "Customer");
            }
        }
    }
}
