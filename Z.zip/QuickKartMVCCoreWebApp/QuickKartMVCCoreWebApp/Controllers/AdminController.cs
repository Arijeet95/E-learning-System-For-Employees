﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Http;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartMVCCoreWebApp.Controllers
{
    //[Route("administrator")]
    public class AdminController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        //[Route("Product")] //Attribute Routing
        public string AddProduct()
        {
            return "This is admin default page";
        }

        public IActionResult AdminHome()
        {
            //Fetching data from session variables into viewdata
            //ViewData["uid"] = HttpContext.Session.GetString("uid");
            //ViewData["role"] = HttpContext.Session.GetString("role");
            //return View();

            TempData["userId"] = HttpContext.Session.GetString("uid");
            TempData["role"] = HttpContext.Session.GetString("role");

            if (TempData["role"].ToString() == "admin")
                return RedirectToAction("Index", "Customer");
            else
                return RedirectToAction("Index", "Home");
        }
    }
}
