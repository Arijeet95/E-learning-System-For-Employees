﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using AutoMapper;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartMVCCoreWebApp.Controllers
{
    public class ProductsController : Controller
    {
        // GET: /<controller>/
        private readonly QuickKartContext _context;
        private readonly IMapper _mapper;
        QuickKartRepository repObj;

        public ProductsController(QuickKartContext context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }

        public IActionResult Index()
        {
            // Fetch data from Entity Framework
            var products = repObj.GetProducts();
            
            //lstproducts is the model object
            List<Models.Products> lstproducts = new List<Models.Products>();

            foreach(var p in products)
            {
                lstproducts.Add(_mapper.Map<Models.Products>(p));
            }

            return View(lstproducts);
        }

        public IActionResult AddProduct()
        {
            string productId = repObj.GetNextProductId();
            ViewBag.NextProductId = productId;
            return View();
        }

        [HttpPost]
        public IActionResult SaveAddedProduct(Models.Products product)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.AddProduct(_mapper.Map<Products>(product));

                    if (status)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return View("Error");
                    }
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
           return View("AddProduct",product);
        }

        public IActionResult UpdateProduct(Models.Products product)
        {
            return View(product);
        }

        [HttpPost]
        public IActionResult SaveUpdatedProduct(Models. Products product)
        {
            bool status = false;
            if(ModelState.IsValid)
            {
                try
                {
                    status = repObj.UpdateProduct(_mapper.Map<Products>(product));
                    if (status)
                        return RedirectToAction("Index");
                    else
                        return View("Error");
                }
                catch(Exception)
                {
                    return View("Error");
                }
            }

            return View("UpdateProduct", product);
        }

        public IActionResult DeleteProduct(Models.Products products)
        {
            return View(products);
        }

        [HttpPost]
        public IActionResult SaveDeletion(string productId)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteProduct(productId);

                if (status)
                    return RedirectToAction("Index");
                else
                    return View("Error");
            }
            catch(Exception)
            {
                return View("Error");
            }
        }

        public IActionResult GetProductsForCategory(byte? categoryId)
        {
            ViewBag.CategoryList = repObj.GetCategories();
            var productList = repObj.GetProducts();
            var products = new List<Models.Products>();
            foreach (var prod in productList)
            {
                products.Add(_mapper.Map<Models.Products>(prod));
            }
            var filterProducts = products.Where(model => model.CategoryId == categoryId);
            return View(filterProducts);
        }
    }
}
