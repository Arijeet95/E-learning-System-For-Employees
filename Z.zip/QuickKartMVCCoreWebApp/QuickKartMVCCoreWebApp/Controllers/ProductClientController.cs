﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System.Net.Http;
using Microsoft.Extensions.Configuration;
using QuickKartMVCCoreWebApp.Repo;

using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;
using AutoMapper;

namespace QuickKartMVCCoreWebApp.Controllers
{
    public class ProductClientController : Controller
    {
        IConfiguration Configuration;
        private readonly QuickKartContext _context;
        private readonly IMapper _mapper;
        QuickKartRepository repObj;

        public ProductClientController(IConfiguration configuration,QuickKartContext context,IMapper mapper)
        {
            Configuration = configuration;
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }

        // GET: ProductClient
        public ActionResult Index()
        {
            ServiceRepository serviceObj = new ServiceRepository(Configuration);
            HttpResponseMessage res = serviceObj.GetResponse("api/Product/GetProducts");
            res.EnsureSuccessStatusCode();

            var products = res.Content.ReadAsAsync<IEnumerable<Models.Products>>().Result;
            return View(products);
        }

        // GET: ProductClient/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ProductClient/Create
        public ActionResult Create()
        {
            string productId = repObj.GetNextProductId();
            ViewBag.NextProductId = productId;
            return View();
        }

        [HttpPost]
        public ActionResult SaveAddedProduct(Models.Products products)
        {
            ServiceRepository serviceObj = new ServiceRepository(Configuration);
            HttpResponseMessage response = serviceObj.PostRequest("api/Product/AddProduct", products);
            response.EnsureSuccessStatusCode();

            if (response.Content.ReadAsAsync<bool>().Result)
                return Redirect("Index");
            else
                return View("Error");
        }

        // POST: ProductClient/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductClient/Edit/5
        public ActionResult Edit(Models.Products products)
        {
            return View("Edit",products);
        }

        // POST: ProductClient/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditDetails(Models.Products products)
        {
            ServiceRepository serviceObj = new ServiceRepository(Configuration);
            HttpResponseMessage response = serviceObj.PutRequest("api/Product/UpdateProduct",products);
            response.EnsureSuccessStatusCode();

            if (response.Content.ReadAsAsync<bool>().Result)
                return RedirectToAction("Index");
            else
                return View("Error");
        }

        // GET: ProductClient/Delete/5
        public ActionResult Delete(Models.Products products)
        {
            return View("Delete",products);
        }

        // POST: ProductClient/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteProductDetails(string productId)
        {
            ServiceRepository serviceObj = new ServiceRepository(Configuration);
            HttpResponseMessage response = serviceObj.DeleteRequest("api/Product/DeleteProduct?ProductId=" + productId);
            response.EnsureSuccessStatusCode();

            if (response.Content.ReadAsAsync<bool>().Result)
                return RedirectToAction("Index");
            else
                return View("Error");
        }
    }
}