﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using AutoMapper;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartMVCCoreWebApp.Controllers
{
    public class CategoriesController : Controller
    {
        // GET: /<controller>/
        private readonly QuickKartContext _context;
        private readonly IMapper _mapper;
        QuickKartRepository repObj;

        public CategoriesController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }

        public IActionResult Index()
        {
            // Fetch data from Entity Framework
            var categories = repObj.GetCategories();

            //lstproducts is the model object
            List<Models.Categories> cstproducts = new List<Models.Categories>();

            foreach (var c in categories)
            {
                cstproducts.Add(_mapper.Map<Models.Categories>(c));
            }

            return View(cstproducts);
        }

        public IActionResult AddCategory()
        {
            byte categoryId = repObj.GetNextCategoryId();
            ViewBag.NextCategoryId = categoryId;
            return View();
        }

        [HttpPost]
        public IActionResult SaveCategory(Models.Categories category)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.AddCategory(_mapper.Map<Categories>(category));

                    if (status)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return View("Error");
                    }
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("AddCategory", category);
        }

        public IActionResult UpdateCategory(Models.Categories category)
        {
            return View(category);
        }

        [HttpPost]
        public IActionResult SaveUpdatedCategory(Models.Categories category)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.UpdateCategory(_mapper.Map<Categories>(category));
                    if (status)
                        return RedirectToAction("Index");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }

            return View("UpdateCategory", category);
        }

        public IActionResult DeleteCategory(Models.Categories category)
        {
            return View(category);
        }

        [HttpPost]
        public IActionResult CatDeletion(Models.Categories category)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteCategory(_mapper.Map<Categories>(category));

                if (status)
                    return RedirectToAction("Index");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
    }
}
