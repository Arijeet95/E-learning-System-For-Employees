﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace QuickKartMVCCoreWebApp.Models
{
    public class Product
    {
        [Required(ErrorMessage = "Category Id is mandatory")]
        public byte? CategoryId { get; set; }

        [Required(ErrorMessage = "Price is mandatory")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Product Id is mandatory")]
        public string ProductId { get; set; }

        [Required(ErrorMessage = "Product Name is mandatory")]
        [StringLength(int.MaxValue, MinimumLength = 3, ErrorMessage = "Product Name should have atleast 3 characters")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Quantity Availaable is mandatory")]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity should be greater than zero")]
        public int QunatityAvailable { get; set; }
    }
}
