﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace QuickKartMVCCoreWebApp.Models
{
    public class Customer
    {
        [Required(ErrorMessage = "Customer Id is mandatory")]
        public int CustomerId { get; set; }
        [Required(ErrorMessage = "Name is mandatory")]
        [StringLength(15,MinimumLength = 3,ErrorMessage ="Name should have atleast 3 characters and max 15 characters")]
        public string CustomerName { get; set; }
        [Range(1,100,ErrorMessage ="Age Should be within 1 to 100")]
        public int Age { get; set; }
        [Required(ErrorMessage ="Phone number is mandatory")]
        public int phone { get; set; }
        [Required(ErrorMessage = "EmailId is mandatory")]
        [EmailAddress(ErrorMessage ="Invalid emaild Id")]
        [DisplayName("Email Address")]
        public string EmailId { get; set; }
    }
}
