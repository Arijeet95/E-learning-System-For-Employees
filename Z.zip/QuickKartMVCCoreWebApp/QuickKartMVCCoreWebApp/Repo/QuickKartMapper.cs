﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using AutoMapper;
using QuickKartDataAccessLayer.Models;

namespace QuickKartMVCCoreWebApp.Repository
{
    public class QuickKartMapper : Profile
    {
        // Entity -> Model
        public QuickKartMapper()
        {
            CreateMap<Products, Models.Products>();
            CreateMap<Categories, Models.Categories>();

            //Model -> Entity
            CreateMap<Models.Products, Products>();
            CreateMap<Models.Categories, Categories>();
        }
        
        
    }
}