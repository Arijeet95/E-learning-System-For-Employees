﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using AutoMapper;
using QuickKartDataAccessLayer.Models;

namespace QuickKartWebServices.Repository
{
    public class QuickMapper : Profile
    {
        public QuickMapper()
        {
            //Entity->Model
            CreateMap<Products, Models.Products>();
            //Model->Entity
            CreateMap<Models.Products, Products>();
        }
    }
}
