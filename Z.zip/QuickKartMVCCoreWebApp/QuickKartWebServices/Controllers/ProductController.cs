﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using AutoMapper;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

namespace QuickKartWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly QuickKartContext _context;
        private readonly IMapper _mapper;
        QuickKartRepository repObj;
        
        public ProductController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }
        
        
        // GET: api/Product
        [HttpGet]
        public JsonResult GetProducts()
        {
            var products = repObj.GetProducts();
            List<Models.Products> lstProd = new List<Models.Products>();
            foreach(var p in products)
            {
                lstProd.Add(_mapper.Map<Models.Products>(p));
            }
            return new JsonResult(lstProd);
        }

        // GET: api/Product/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Product
        [HttpPost]
        public bool AddProduct(Models.Products products)
        {
            bool status = false;
            try
            {
                Products p = new Products();
                p.ProductId = products.ProductId;
                p.ProductName = products.ProductName;
                p.CategoryId = products.CategoryId;
                p.Price = products.Price;
                p.QuantityAvailable = products.QuantityAvailable;

                status = repObj.AddProduct(p);
            }
            catch
            {
                status = false;
            }
            return status;
        }      

        // PUT: api/Product/5
        [HttpPut]
        public bool UpdateProduct(Models.Products products)
        {
            bool status = false;
            try
            {
                Products p = new Products();
                p.ProductId = products.ProductId;
                p.ProductName = products.ProductName;
                p.CategoryId = products.CategoryId;
                p.Price = products.Price;
                p.QuantityAvailable = products.QuantityAvailable;

                status = repObj.UpdateProduct(p);
            }
            catch
            {
                status = false;
            }
            return status;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete]
        public bool DeleteProduct(string productId)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteProduct(productId);
            }
            catch
            {
                status = false;
            }
            return status;
        }
    }
}
